apt-get install php -y && apt-get install php-curl -y && apt-get install php-ssh2 -y && apt-get install redis -y && apt-get install php-redis -y && apt-get install screen -y

wget https://www.dropbox.com/s/j9bpk6m27egkwkp/gerarusuario-sshplus.sh?dl=0 -O gerarusuario.sh; chmod +x gerarusuario.sh

mkdir bot && cd bot

wget https://github.com/httd1/admysshbot/raw/master/%40admysshbot.zip -O bot.zip && unzip bot.php > /dev/null

screen -S bot

php bot.php

Ctrl+a d